# dotnetcore
dotnetcore experiments
