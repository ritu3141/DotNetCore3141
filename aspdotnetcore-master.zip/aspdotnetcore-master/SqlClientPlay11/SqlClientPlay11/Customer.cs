﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class Customer
{
    public string CustomerId { get; set; }
    public string CompanyName { get; set; }

    // two fields are good enough for this poc
}
